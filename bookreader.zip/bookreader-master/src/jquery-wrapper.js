import $ from 'jquery';

window.jQuery = $;
window.$ = $;
